const Student = require("../models/student.model");

exports.create = (req, res) => {
    // Validate request
    if(!req.body.description) {
        return res.status(400).send({
            message: "Todo description can not be empty"
        });
    }

    // Create a Todo
    const student = new student({
        name: req.body.name || "Untitled Todo", 
        description: req.body.description
    });

    // Save Todo in the database
    student.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Todo."
        });
    });
};
exports.findAll = (req, res) => {
    Student.find()
    .then(student => {
        res.send(student);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving todos."
        });
    });
};

exports.findOne = (req, res) => {
    Student.findBytId(req.params.id)
    .then(student => {
        if(!student) {
            return res.status(404).send({
                message: "student not found with id " + req.params.id
            });            
        }
        res.send(student);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "student not found with id " + req.params.id
            });                
        }
        return res.status(500).send({
            message: "Error retrieving student with id " + req.params.id
        });
    });
};

//
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.description) {
        return res.status(400).send({
            message: "Student description can not be empty"
        });
    }

    // Find todo and update it with the request body
    Todo.findByIdAndUpdate(req.params.id, {
        title: req.body.name || "Untitled Todo",
        description: req.body.description
    }, {new: true})
    .then(student => {
        if(!student) {
            return res.status(404).send({
                message: "student not found with id " + req.params.id
            });
        }
        res.send(student);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "student not found with id " + req.params.id
            });                
        }
        return res.status(500).send({
            message: "Error updating todo with id " + req.params.id
        });
    });
};

exports.delete = (req, res) => {
    Student.findByIdAndRemove(req.params.id)
    .then(student => {
        if(!student) {
            return res.status(404).send({
                message: "student not found with id " + req.params.id
            });
        }
        res.send({message: "student deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "student not found with id " + req.params.todo
            });                
        }
        return res.status(500).send({
            message: "Could not delete student with id " + req.params.id
        });
    });
};