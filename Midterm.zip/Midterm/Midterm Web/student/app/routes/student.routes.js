module.exports = (app) => {
    const student = require('../controllers/student.controller.js');

    // Create a new todo
    app.post('/student', student.create);

    // Retrieve all todos
    app.get('/student', student.findAll);

    // Retrieve a single todo by id
    app.get('/student/:id', student.findOne);

    // Update a Todo with id
    app.put('/student/:id', student.update);

    // Delete a Todo by id
    app.delete('/student/:id', student.delete);
}

const express = require('express');
const router = express.Router();

// Define the GET /students route
router.get('/students', (req, res) => {
  // Your logic to fetch all students from the database and send the response
});

module.exports = router;
